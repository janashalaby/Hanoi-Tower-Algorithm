#include <iostream>
using namespace std;

int exp(int n) { // n is the number of disks that the user entered
    int two = 1;
    for (int i = 0; i < n; ++i) { 
        two *= 2;
    }
    two = two - 1;
    return two;
}

int main()
{
    int disk;
    int start = 1; //first disk
    int middle = 2; //middle disk
    int last = 3; //last disk
    cout << "Please enter the number of disks: ";
    cin >> disk;
    cout << endl;

    if (disk <= 0) cout << "You entered an invalid number." << endl;

    else if (disk % 2 == 0) {   //if number of disks is even program will go through the loop
        for (int j = 1; j <= exp(disk); j++) {

            cout << "Move disk " << "1" << " from tower A to tower B." << endl;
            cout << "Move disk " << "2" << " from tower A to tower C." << endl;
            cout << "Move disk " << "3" << " from tower B to tower C." << endl;

        }
    }
    else if (disk % 2 == 1) {   // if number of disks is odd program will go through this loop and skip the another one
        for (int j = 1; j <= exp(disk); j++) {

            cout << "Move disk " << "1" << " from tower A to tower C." << endl;
            cout << "Move disk " << "2" << " from tower A to tower B." << endl;
            cout << "Move disk " << "3" << " from tower C to tower B." << endl;

        }
    }

    return 0;
}
