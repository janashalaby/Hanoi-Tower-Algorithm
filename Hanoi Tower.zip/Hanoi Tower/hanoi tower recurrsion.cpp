#include<iostream>
using namespace std;

void move(int, int, int, int);

int main() {

	int num;
	cout << "Hey user please enter number of disks" << endl;
	cin >> num; // number of disks choosen by user .
	cout << endl;
	move(num, 1, 2, 3);

	return 0;
}

void move(int count, int num1, int num2, int num3) {
	// if count is bigger than zero then the  program will excute this function over and over again until count get to 0
	//count is means  the  number of disks
	if (count > 0) { 
		            
		move(count - 1, num1, num2, num3); // function call that moves the disk from need 1 to needle 3
		cout << "Move Disk " << count << " from " << num1 << " to " << num3 << endl;
		move(count - 1, num2, num3, num1);// function call that moves the disk from need 2 to needle 3
	}
}
